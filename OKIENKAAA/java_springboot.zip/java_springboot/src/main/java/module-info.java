module com.example.projekt3okienka {
    // Wymagane moduły do obsługi JavaFX
    requires javafx.controls;
    requires javafx.fxml;

    // Moduły używane przez JavaFX i dodatkowe kontrolki (ControlsFX)
    requires org.controlsfx.controls;

    // Wymagane moduły do działania Spring Boot
    requires spring.boot;
    requires spring.boot.autoconfigure;
    requires spring.context;
    requires spring.web;
    //requires spring.data.jpa;
    requires spring.core;
    requires spring.beans;
    //requires spring.jdbc;

    // Wymagane moduły do obsługi baz danych i JPA (Hibernate)
  //  requires java.sql;
   // requires java.persistence;
    //requires mysql.connector.j;

    // Obsługa JSON i serializacji z użyciem Jacksona
    requires com.fasterxml.jackson.databind;
    requires com.fasterxml.jackson.core;
    requires com.fasterxml.jackson.annotation;

    // Dodatkowe moduły JDK
    requires java.desktop;

    // Eksportowanie pakietów (publicznie dostępne klasy)
    exports com.example.projekt3okienka;
    exports com.example.demo;
    //exports com.example.Controllers;

    // Otwieranie pakietów dla JavaFX, Spring Boot, Jackson, Hibernate i innych narzędzi
    opens com.example.projekt3okienka to
            javafx.fxml,
            javafx.graphics,
            spring.core,
            spring.beans,
            spring.boot,
            com.fasterxml.jackson.databind; // Dodano otwarcie dla Jacksona

    opens com.example.demo to
            javafx.fxml,
            javafx.graphics,
            spring.core,
            spring.beans,
            spring.boot,
            com.fasterxml.jackson.databind; // Dodano otwarcie dla Jacksona

  /*  opens com.example.Controllers to
            javafx.fxml,
            javafx.graphics,
            spring.core,
            spring.beans,
            spring.boot,
            com.fasterxml.jackson.databind; // Dodano otwarcie dla Jacksona */
}