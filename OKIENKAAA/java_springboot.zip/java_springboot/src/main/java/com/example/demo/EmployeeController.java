package com.example.demo;

import com.example.projekt3okienka.Employee;
import com.example.projekt3okienka.EmployeeCondition;
import javafx.beans.property.*;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
@RestController
@RequestMapping("/api/employee")
public class EmployeeController {


        // Lista pracowników (symulacja bazy danych w pamięci)
        private final List<Employee> employees = new ArrayList<>();

        // POST: /api/employee - Dodanie nowego pracownika
        @PostMapping
        public Employee addEmployee(@RequestBody Employee employee) {
            employees.add(employee);
            System.out.println("Dodano pracownika: " + employee);
            return employee; // Zwracamy dodanego pracownika (opcjonalnie)
        }

        // GET: /api/employee - Zwrócenie listy wszystkich pracowników
        @GetMapping
        public List<Employee> getAllEmployees() {
            return employees;
        }
    }